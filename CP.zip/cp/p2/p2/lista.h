struct nodo {
  void *elem; /* ’void *’ es un apuntador ’generico’ */
  struct nodo *sig;
};

typedef struct nodo *posicion;

typedef struct nodo *lista;

lista crearlista();

int eslistavacia(lista l);

void insertar(void *e, posicion p); /*inserta e tras el nodo apuntado por p*/

void borrarlista(lista l);

posicion buscar(lista l, void *e, int (*comp)(const void *x, const void *y)); /*la funci´on comp devuelve un n´umero mayor, igual o menor que cero, seg´un x sea mayor, igual, o menor que y*/

void borrar(lista l, void *e, int (*comp)(const void *x, const void *y));

posicion primero(lista l);

posicion siguiente(posicion p);

int esfindelista(posicion p);

void *elemento(posicion p);

int findelista(lista l);

posicion ultimo(lista l);


/* Para recorrer los elementos de la lista:
for(p=primero(l); !esfindelista(p); p=siguiente(p)) {
//hacer algo con elemento(p)
}
*/
