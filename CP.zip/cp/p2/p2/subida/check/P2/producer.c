
#include <errno.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdbool.h>
#include "options.h"
#include "lista.h"

/* creation and consumption of elements */

/**
 * Element: Describe one of the elements that we work with
 *
 * @producer: which thread has created the element
 * @value: What is the producer value
 * @time: how long it took to generate the value in microseconds
 */
struct element {
	int producer;
	int value;
	int time;
};

pthread_mutex_t create_mutex = PTHREAD_MUTEX_INITIALIZER;
int created_elements = 0;;

/**
 * element_create: creates a new element
 *
 * @producer: thread that produces it
 * @seed: this is needed for the random generator to work
 */
struct element *element_create(int producer, unsigned int *seed)
{
	struct element *e = malloc(sizeof(*e));
	if (e == NULL) {
		printf("Ont of memory");
		exit(-1);
	}
	e->producer = producer;
	e->value = rand_r(seed) % 1000;
	e->time = rand_r(seed) % 100000;
	usleep(e->time);

	pthread_mutex_lock(&create_mutex);
	created_elements++;
	pthread_mutex_unlock(&create_mutex);
	return e;
}

pthread_mutex_t consume_mutex = PTHREAD_MUTEX_INITIALIZER;
int consumed_elements = 0;;

/**
 * element_consume: creates a new element
 *
 * @producer: thread that produces it
 * @seed: this is needed for the random generator to work
 */
void element_consume(struct element *e)
{
	usleep(e->time);
	free(e);
	pthread_mutex_lock(&consume_mutex);
	consumed_elements++;
	pthread_mutex_unlock(&consume_mutex);
}

/* queue implementation */

/**
 * Queue: Queue of elements
 *
 * @elements: array of elements that would store the values
 * @count: number of used elements
 * @size: size in elements of elements array
 * @insertions: how many insertions have we got in the whole lifetime
 */
struct queue {
	struct element **elements;
	int count;
	int size;
	int insertions;
};

/**
 * queue_create: create a new queue
 *
 * @size: size of the queue
 */
static struct queue *queue_create(int size)
{
	struct queue *queue =  malloc(sizeof(struct queue));
	queue->size = size;
	queue->count = 0;
	queue->insertions = 0;
	queue->elements = malloc(sizeof(struct element) * size);

	return queue;
}

/**
 * queue_destroy: destroy a queue
 *
 * Destroy the queue and frees its memory
 *
 * @queue: queue to destroy
 */
static void queue_destroy(struct queue *queue)
{
	if (queue->count != 0) {
		printf("queue still has %d elements\n", queue->count);
	}
	free(queue->elements);
	free(queue);
}

/**
 * queue_is_empty: returns true if the queue is empty
 *
 * @queue: queue to check
 */
static bool queue_is_empty(struct queue *queue)
{
	return queue->count == 0;
}

/**
 * queue_is_full: returns true if the queue is full
 *
 * @queue: queue to check
 */
static bool queue_is_full(struct queue *queue)
{
	return queue->count == queue->size;
}

/**
 * queue_insertions: returns the number of instertions
 *
 * @queue: queue to check
 */
static int queue_insertions(struct queue *queue)
{
	return queue->insertions;
}

/**
 * queue_insert: inserts a new element on the queue
 *
 * @queue: queue where to insert
 * @element: element to insert
 */
static void queue_insert(struct queue *queue, struct element *element)
{
	if (queue->count == queue->size) {
		printf("buffer is full\n");
		exit(-1);
	}
	queue->elements[queue->count] = element;
	queue->count++;
	queue->insertions++;
}

/**
 * queue_remove: remove an element in the queue
 *
 * Returns the element removed
 *
 * @queue: queue where to remove
 */
struct element *queue_remove(struct queue *queue)
{
	if (queue->count == 0) {
		printf("buffer is empty\n");
		exit(-1);
	}
	queue->count--;
	return queue->elements[queue->count];
}

pthread_cond_t buffer_full = PTHREAD_COND_INITIALIZER;
pthread_cond_t buffer_empty = PTHREAD_COND_INITIALIZER;

pthread_mutex_t buffer_mutex = PTHREAD_MUTEX_INITIALIZER;



/**
 * thread_info: Information needed for each created thread
 *
 * @thread_id: pthread identifier for the thread
 * @thread_num: numerical identifier for our application
 */
struct thread_info {    /* Used as argument to thread_start() */
	pthread_t thread_id;        /* ID returned by pthread_create() */
	int       thread_num;       /* Application-defined thread # */
};

/**
 * producer_args: Arguments passed to each producer thread
 *
 * @thread_num: numerical identifier for our application
 * @queue: queue into which insert produced elements
 */
struct producer_args {
	int thread_num;
	struct queue *queue;
	int *ite_producer;
	pthread_mutex_t *itemutex_producer;
	struct producer_stadistics *stadistics;
	int *full;
	int full_max;
	pthread_mutex_t *mutex_full;
	pthread_cond_t *cond_llena;
};

struct producer_stadistics{
	int element_produce;
	int element_total_time;
	int full;
};

/**
 * producer_function: function executed by each producer thread
 *
 * @ptr: producer_args that needs to be passed as void
 */
void *producer_function(void *ptr)
{
	struct producer_args *args = ptr;
	unsigned int seed = args->thread_num;

	printf("producer thread %d\n", args->thread_num);
	while(1) {

		pthread_mutex_lock(args->itemutex_producer);
		if(*(args->ite_producer)==0){
			pthread_mutex_unlock(args->itemutex_producer);
			break;
		}
		(*(args->ite_producer))--;
		pthread_mutex_unlock(args->itemutex_producer);


		bool is_empty;
		struct element *e = element_create(args->thread_num, &seed);
		args->stadistics->element_total_time += e->time;
		args->stadistics->element_produce++;

		printf("%d: produces %d in %d microseconds\n", args->thread_num, e->value, e->time);
		pthread_mutex_lock(&buffer_mutex);

		while(queue_is_full(args->queue)) {
			args->stadistics->full++;
			pthread_mutex_lock(args->mutex_full);
			(*(args->full))++;
			if ((*(args->full)) == args->full_max) {
				pthread_cond_broadcast((args->cond_llena));
			}
			pthread_mutex_unlock(args->mutex_full);
			pthread_cond_wait(&buffer_full, &buffer_mutex);
		}
		is_empty = queue_is_empty(args->queue);
		queue_insert(args->queue, e);
		if(is_empty)
			pthread_cond_broadcast(&buffer_empty);
		pthread_mutex_unlock(&buffer_mutex);
	}
	return NULL;
}

/**
 * consumer_args: Arguments passed to each consumer thread
 *
 * @thread_num: numerical identifier for our application
 * @queue: queue from where to remove elements
 */
struct consumer_args {
	int thread_num;
	struct queue *queue;
	int *ite_consumer;
	pthread_mutex_t *itemutex_consumer;
	struct consumer_stadistics *stadistics;
	int *empty;
	int empty_max;
	pthread_mutex_t *mutex_empty;
	pthread_cond_t *cond_vacia;
	int matate;
	pthread_mutex_t mutex_matate;
};

struct consumer_stadistics{
	int element_consume;
	int element_total_time;
	int empty;
};

/**
 * consumer_function: function executed by each consumer thread
 *
 * @ptr: consumer_args that needs to be passed as void
 */
void *consumer_function(void *ptr)
{
	struct consumer_args *args = ptr;

	printf("consumer thread %d\n", args->thread_num);
	while(1) {

		pthread_mutex_lock(&(args->mutex_matate));
		if (args->matate){
			pthread_mutex_unlock(&(args->mutex_matate));
			return NULL;
		}
		pthread_mutex_unlock(&(args->mutex_matate));

		pthread_mutex_lock(args->itemutex_consumer);
		if(*(args->ite_consumer)==0){
			pthread_mutex_unlock(args->itemutex_consumer);
			break;
		}
		(*(args->ite_consumer))--;
		pthread_mutex_unlock(args->itemutex_consumer);

		struct element *e;
		bool is_full;
		pthread_mutex_lock(&buffer_mutex);
		while(queue_is_empty(args->queue)){
			args->stadistics->empty++;
			pthread_mutex_lock(args->mutex_empty);
			(*(args->empty))++;
			if ((*(args->empty)) == args->empty_max) {
				pthread_cond_broadcast((args->cond_vacia));
			}
			pthread_mutex_unlock(args->mutex_empty);

			pthread_cond_wait(&buffer_empty, &buffer_mutex);
		}
		is_full = queue_is_full(args->queue);
		e = queue_remove(args->queue);
		args->stadistics->element_total_time+=e->time;
		args->stadistics->element_consume++;
		if(is_full)

			pthread_cond_broadcast(&buffer_full);
		pthread_mutex_unlock(&buffer_mutex);

		printf("%d: consumes %d in %d microseconds\n", args->thread_num, e->value, e->time);
		element_consume(e);
	}
	return NULL;
}

struct up_consumer{
	struct queue *queue;
	pthread_cond_t *cond_llena;
	int *full;
	int full_max;
	pthread_mutex_t *mutex_full;
	lista l_args;
	lista l_info;
	lista l_statistics;
	struct thread_info *info;
	pthread_mutex_t *itemutex_consumer;
	int *ite_consumer;
	int *empty;
	int empty_max;
	pthread_mutex_t *mutex_empty;
	pthread_cond_t *cond_vacia;

};

struct down_consumer{
	struct queue *queue;
	lista l_args;
	lista l_info;
	lista l_statistics;
	pthread_mutex_t *itemutex_consumer;
	int *ite_consumer;
	int *empty;
	int empty_max;
	pthread_mutex_t *mutex_empty;
	pthread_cond_t *cond_vacia;

};


/**
 * producer_create: creates a new producer
 *
 * @info: thread information of created producer
 * @args: args passed to created thread
 * @thread_num: number id of created thread
 * @queue: where to insert producer elements
 */
void producer_create(struct thread_info *info, struct producer_args *args,
		     int thread_num, struct queue *queue, struct producer_stadistics *stadistics)
{
	info->thread_num = thread_num;
	args->thread_num = thread_num;
	args->queue = queue;
	args->stadistics = stadistics;

	if ( 0 != pthread_create(&info->thread_id, NULL,
				 producer_function, args)) {
		printf("Failing creating consumer thread %d", thread_num);
		exit(1);
	}
}

/**
 * consumer_create: creates a new consumer
 *
 * @info: thread information of created consumer
 * @args: args passed to created thread
 * @thread_num: number id of created thread
 * @queue: where to remove elements
 */
void consumer_create(struct thread_info *info, struct consumer_args *args,
		     int thread_num, struct queue *queue, struct consumer_stadistics *stadistics)
{
	info->thread_num = thread_num;
	args->thread_num = thread_num;
	args->queue = queue;
	args->stadistics = stadistics;
	if ( 0 != pthread_create(&info->thread_id, NULL,
				 consumer_function, args)) {
		printf("Failing creating consumer thread %d", thread_num);
		exit(1);
	}
}

void * up_consumer_function(void *ptr){

	struct up_consumer *arg = ptr;
	struct consumer_args *consumer_arg;
	posicion p_stat = NULL,p_arg = NULL,p_info = NULL;
	struct consumer_stadistics *consumer_stadistics;
	struct thread_info *consumer_infos;

	while (1) {

		pthread_mutex_lock(arg->mutex_full);

		while ((((*(arg->full)) < arg->full_max))) {
			pthread_cond_wait(arg->cond_llena,arg->mutex_full);

			pthread_mutex_lock(arg->itemutex_consumer);
			if (*(arg->ite_consumer) <= 0){
				pthread_mutex_unlock(arg->itemutex_consumer);
				pthread_mutex_unlock(arg->mutex_full);
				return NULL;
			}
			pthread_mutex_unlock(arg->itemutex_consumer);
		}

		pthread_mutex_lock(arg->itemutex_consumer);
		if (arg->ite_consumer == 0){
			pthread_mutex_unlock(arg->itemutex_consumer);
			break;
		}
		pthread_mutex_unlock(arg->itemutex_consumer);

		(*(arg->full)) = 0;


		//Inicializacion de consumers arg
		p_stat = ultimo(arg->l_statistics);

		consumer_stadistics = malloc(sizeof(struct consumer_stadistics));
		consumer_stadistics->element_consume = 0;
		consumer_stadistics->element_total_time = 0;
		consumer_stadistics->empty = 0;
		insertar(consumer_stadistics,p_stat);


		consumer_arg = malloc(sizeof(struct consumer_args));
		if (consumer_arg==NULL) exit(1);

		p_arg = ultimo(arg->l_args);
		consumer_arg->thread_num = findelista(arg->l_args);
		consumer_arg->queue = arg->queue;
		consumer_arg->ite_consumer = arg->ite_consumer;
		consumer_arg->itemutex_consumer = arg->itemutex_consumer;
		consumer_arg->empty_max = arg->empty_max;
		consumer_arg->empty = arg->empty;
		consumer_arg->mutex_empty = arg->mutex_empty;
		consumer_arg->cond_vacia = arg->cond_vacia;
		consumer_arg->matate = 0;
		pthread_mutex_init(&(consumer_arg->mutex_matate),NULL);

		insertar(consumer_arg,p_arg);

		p_info = ultimo(arg->l_info);
		consumer_infos = malloc(sizeof(struct thread_info));
		if (consumer_infos==NULL) exit(1);
		consumer_infos->thread_num = consumer_arg->thread_num;
		insertar(consumer_infos,p_info);
		consumer_create(consumer_infos,consumer_arg,
				     consumer_arg->thread_num,arg->queue, consumer_stadistics);


		pthread_mutex_unlock(arg->mutex_full);
	}
	return NULL;
}


void *down_consumer_function(void * ptr){
	struct down_consumer *arg = ptr;
	lista l_args = arg->l_args;
	posicion p;
	struct consumer_args *c_args;

	while (1) {

		pthread_mutex_lock(arg->mutex_empty);
		while ((((*(arg->empty)) < arg->empty_max))) {
			pthread_cond_wait(arg->cond_vacia,arg->mutex_empty);

			pthread_mutex_lock(arg->itemutex_consumer);

			if (*(arg->ite_consumer) <= 0){
				pthread_mutex_unlock(arg->itemutex_consumer);
				pthread_mutex_unlock(arg->mutex_empty);
				return NULL;
			}
			pthread_mutex_unlock(arg->itemutex_consumer);
		}

		//Aqui mato un thread

		for(p=primero(l_args); !esfindelista(p); p=siguiente(p)) {
			c_args = p->elem;

			if (c_args->matate == 0)
				break;
		}

		if (p != NULL){
			c_args = p->elem;
			pthread_mutex_lock(&(c_args->mutex_matate));
			c_args->matate=1;
			pthread_mutex_unlock(&(c_args->mutex_matate));
			printf("thread muerto *******************************************\n");
		}
	*(arg->empty) = 0;
	pthread_mutex_unlock(arg->mutex_empty);
	}
}

void print_producers_stadistics(lista l){
	posicion p;
	struct producer_stadistics *aux;
	int i = 0;
	for(p=primero(l); !esfindelista(p); p=siguiente(p)) {
		aux = p->elem;
		printf("******************\n");
		printf("Productor numero: %d\n", i);
		printf("Elementos producidos: %d\n",aux->element_produce);
		printf("Tiempo medio: %d\n", aux->element_total_time/aux->element_produce);
		printf("Cola llena: %d\n",aux->full);
		i++;
	}
}

void print_consumers_stadistics(lista l){
	posicion p;
	struct consumer_stadistics *aux;
	int i = 0;
	for(p=primero(l); !esfindelista(p); p=siguiente(p)) {
		aux = p->elem;
		printf("******************\n");
		printf("Consumidor numero: %d\n", i);
		printf("Elementos consumidos: %d\n",aux->element_consume);
		printf("Tiempo medio: %d\n", aux->element_total_time/aux->element_consume);
		printf("Cola vacia: %d\n",aux->empty);
		i++;
	}
}

void print_main_stadistics(struct queue *queue, lista lista_productores, lista lista_consumidores){
	int n_productores = 0,n_consumidores = 0, elements_produce = 0, elements_consume = 0;
	posicion p;
	struct producer_stadistics *aux_p;
	struct consumer_stadistics *aux_c;

	for(p=primero(lista_productores); !esfindelista(p); p=siguiente(p)) {
		aux_p = p->elem;
		elements_produce += aux_p->element_produce;
		n_productores++;
	}

	for(p=primero(lista_consumidores); !esfindelista(p); p=siguiente(p)) {
		aux_c = p->elem;
		elements_consume += aux_c->element_consume;
		n_consumidores++;
	}

	printf("******************\n");
	printf("Elementos producidos: %d\n", elements_produce);
	printf("Elementos consumidos: %d\n", elements_consume);
	printf("Elementos insertados: %d\n", queue_insertions(queue));
	printf("%s \n", ( queue_is_empty(queue)) ? "Cola Vacia": "Cola no Vacia");


}
/**
 * producers_consumer: creates and wait to finish for producers and consumers
 *
 * @opt: command line options
 */
void producers_consumers(struct options *opt)
{
	int i;
	struct thread_info *thread_struct;
	lista producer_infos = crearlista();
	lista producer_args = crearlista();
	lista producers_stadistics = crearlista();
	lista consumer_infos = crearlista();
	lista consumer_args = crearlista();
	lista consumers_stadistics = crearlista();
	posicion p,p2,p3;
	struct thread_info *thread_info;
	struct producer_args *producer_args_struct;
	struct consumer_args *consumer_args_struct;
	struct queue *queue;
	pthread_mutex_t itemutex_consumer;
	pthread_mutex_t itemutex_producer;
	int ite_consumer = opt->iterations;
	int ite_producer = opt->iterations;
	struct producer_stadistics *producer_stadistics_struct;
	struct consumer_stadistics *consumer_stadistics_struct;
	pthread_mutex_t mutex_full;
	int full = 0;
	pthread_cond_t cond_llena = PTHREAD_COND_INITIALIZER;
	struct up_consumer up_consumer;
	struct down_consumer down_consumer;
	struct thread_info thread_control;
	struct thread_info thread_control_down;
	pthread_cond_t cond_vacia = PTHREAD_COND_INITIALIZER;
	pthread_mutex_t mutex_empty;
	int empty = 0;

	printf("creating buffer with %d elements\n", opt->buffer_size);
	queue = queue_create(opt->buffer_size);

	if (queue == NULL) {
		printf("Not enough memory\n");
		exit(1);
	}

	printf("creating control threads\n");
	pthread_mutex_init(&mutex_empty,NULL);
	pthread_mutex_init(&mutex_full,NULL);

	up_consumer.queue = queue;
	up_consumer.full = &full;
	up_consumer.full_max = opt->cola_llena;
	up_consumer.cond_llena = &cond_llena;
	up_consumer.mutex_full = &mutex_full;
	up_consumer.l_args = consumer_args;
	up_consumer.l_info = consumer_infos;
	up_consumer.l_statistics = consumers_stadistics;
	up_consumer.ite_consumer = &ite_consumer;
	up_consumer.itemutex_consumer = &itemutex_consumer;
	up_consumer.empty = &empty;
	up_consumer.empty_max = opt->cola_vacia;
	up_consumer.mutex_empty = &mutex_empty;
	up_consumer.cond_vacia = &cond_vacia;


	if ( 0 != pthread_create(&(thread_control.thread_id), NULL, up_consumer_function, &up_consumer)) {
		printf("Failing creating consumer thread");
		exit(1);
	}

	down_consumer.queue = queue;
	down_consumer.l_args = consumer_args;
	down_consumer.l_info = consumer_infos;
	down_consumer.l_statistics = consumers_stadistics;
	down_consumer.itemutex_consumer = &itemutex_consumer;
	down_consumer.ite_consumer = &ite_consumer;
	down_consumer.empty = &empty;
	down_consumer.empty_max = opt->cola_vacia;
	down_consumer.mutex_empty = &mutex_empty;
	down_consumer.cond_vacia = &cond_vacia;

	if ( 0 != pthread_create(&(thread_control_down.thread_id), NULL, down_consumer_function, &down_consumer)) {
		printf("Failing creating consumer thread");
		exit(1);
	}

	printf("creating %d producers\n", opt->num_producers);

	/* Creacion de la lista de productores */
	p = producer_infos;
	for (i = 0; i < opt->num_producers; i++) {
		thread_struct = malloc(sizeof(struct thread_info));

		if (thread_struct == NULL) {
			printf("Not enough memory\n");
			exit(1);
		}

		insertar(thread_struct,p);
		p = siguiente(p);
	}


	/* Inicializacion de la lista producer_args */
	pthread_mutex_init(&itemutex_producer,NULL);



	p = producer_args;
	for (i = 0; i < opt->num_producers; i++) {
		producer_args_struct = malloc(sizeof(struct producer_args));

		if (producer_args_struct == NULL) {
			printf("Not enough memory\n");
			exit(1);
		}

		producer_args_struct->full 								= &full;
		producer_args_struct->full_max						= opt->cola_llena;
		producer_args_struct->mutex_full					= &mutex_full;
		producer_args_struct->itemutex_producer		= &itemutex_producer;
		producer_args_struct->ite_producer 				= &ite_producer;
		producer_args_struct->cond_llena					= &cond_llena;

		insertar(producer_args_struct,p);

		p = siguiente(p);
	}

	/****************************************/


	p = producers_stadistics;
	for (i = 0; i < opt->num_producers; i++) {
		producer_stadistics_struct = malloc(sizeof(struct producer_stadistics));

		if (producer_stadistics_struct == NULL) {
			printf("Not enough memory\n");
			exit(1);
		}

		producer_stadistics_struct->element_produce			= 0;
		producer_stadistics_struct->element_total_time	= 0;
		producer_stadistics_struct->full 								= 0;

		insertar(producer_stadistics_struct,p);
		p = siguiente(p);
	}
	/************************/

	/* Create independent threads each of which will execute function */
	p = primero(producer_infos);
	p2 = primero(producer_args);
	p3 = primero(producers_stadistics);
	for (i = 0; i < opt->num_producers; i++) {
		producer_create(p->elem, p2->elem, i, queue, p3->elem);
		p = siguiente(p);
		p2 = siguiente(p2);
		p3 = siguiente(p3);
	}

	printf("creating %d consumers\n", opt->num_consumers);

	/* Inicialización lista consumer_infos */

	p = consumer_infos;
	for (i = 0; i < opt->num_consumers; i++) {
		thread_struct = malloc(sizeof(struct thread_info));

		if (thread_struct == NULL) {
			printf("Not enough memory\n");
			exit(1);
		}

		insertar(thread_struct,p);
		p = siguiente(p);
	}

	/* Inicialización lista consumer_args */

	p = consumer_args;
	for (i = 0; i < opt->num_consumers; i++) {
		consumer_args_struct = malloc(sizeof(struct consumer_args));

		if (consumer_args_struct == NULL) {
			printf("Not enough memory\n");
			exit(1);
		}

		consumer_args_struct->itemutex_consumer = &itemutex_consumer;
		consumer_args_struct->ite_consumer = &ite_consumer;
		consumer_args_struct->empty = &empty;
		consumer_args_struct->empty_max = opt->cola_vacia;
		consumer_args_struct->mutex_empty = &mutex_empty;
		consumer_args_struct->cond_vacia = &cond_vacia;
		consumer_args_struct->matate = 0;
		pthread_mutex_init(&(consumer_args_struct->mutex_matate),NULL);

		insertar(consumer_args_struct,p);
		p = siguiente(p);
	}


	/*Inicializar mutex y asignar iterador y mutex a args*/
		pthread_mutex_init(&itemutex_consumer,NULL);

		p = consumers_stadistics;
		for (i = 0; i < opt->num_consumers; i++) {
			consumer_stadistics_struct = malloc(sizeof(struct consumer_stadistics));

			if (consumer_stadistics_struct == NULL) {
				printf("Not enough memory\n");
				exit(1);
			}

			consumer_stadistics_struct->element_consume				= 0;
			consumer_stadistics_struct->element_total_time		= 0;
			consumer_stadistics_struct->empty 								= 0;

			insertar(consumer_stadistics_struct,p);
			p = siguiente(p);
		}

	/************************/

	p = primero(consumer_infos);
	p2 = primero(consumer_args);
	p3 = primero(consumers_stadistics);
	for (i = 0; i < opt->num_consumers; i++) {
		consumer_create(p->elem, p2->elem, i, queue, 	p3->elem);
		p = siguiente(p);
		p2 = siguiente(p2);
		p3 = siguiente(p3);
	}


	p = primero(producer_infos);
	for (i = 0; i < opt->num_producers; i++) {
		thread_info = p->elem;
		pthread_join(thread_info->thread_id, NULL);
		p = siguiente(p);
	}

	p = primero(consumer_infos);
	for (p = primero(consumer_infos); !esfindelista(p); p = siguiente(p)) {
		thread_info = p->elem;
		pthread_join(thread_info->thread_id, NULL);
	}

	pthread_cond_broadcast(&cond_llena);
	pthread_cond_broadcast(&cond_vacia);
	pthread_cond_broadcast(&cond_llena);
	pthread_cond_broadcast(&cond_vacia);

	print_producers_stadistics(producers_stadistics);
	print_consumers_stadistics(consumers_stadistics);
	print_main_stadistics(queue, producers_stadistics, consumers_stadistics);

	pthread_cond_broadcast(&cond_llena);
	pthread_cond_broadcast(&cond_vacia);

	pthread_join(thread_control.thread_id,NULL);
	pthread_join(thread_control_down.thread_id,NULL);


	borrarlista(producer_args);
	borrarlista(producer_infos);
	borrarlista(consumer_args);
	borrarlista(consumer_infos);
	borrarlista(producers_stadistics);
	borrarlista(consumers_stadistics);
	queue_destroy(queue);
}

int main (int argc, char **argv)
{
	struct options opt;

	opt.num_producers = 2;
	opt.num_consumers = 2;
	opt.buffer_size = 1;
	opt.iterations = 100;
	opt.cola_llena = 10;
	opt.cola_vacia = 10;

	read_options(argc, argv, &opt);

	producers_consumers(&opt);

	pthread_exit (0);
}
